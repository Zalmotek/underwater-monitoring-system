#include <main_thread.h>

#include <math.h>

#include <serial/serial.h>

extern "C" {

  #include <wire/wire.h>

}

#define INTERVAL_MS 20

#define HS300X_IC2_ADDR 0x44

#define HS300X_MEAS_REQUEST 0x00
#define HS300X_DATA_LEN_BYTE 4

#define HS300X_WAKEUP_TIME_MS 1
#define HS300X_MEASURE_TIME_MS 100
#define HS300X_EVENT_WAIT_TIMEOUT_MS 1000

#define HS300X_WAKEUP_TIME_TICKS pdMS_TO_TICKS(HS300X_WAKEUP_TIME_MS)
#define HS300X_MEASURE_TIME_TICKS pdMS_TO_TICKS(HS300X_MEASURE_TIME_MS)
#define HS300X_EVENT_WAIT_TIMEOUT_TICKS pdMS_TO_TICKS(HS300X_EVENT_WAIT_TIMEOUT_MS)

SerialPort USBSerial;
float temp, humidity;

static fsp_err_t hs300x_temp(float * p_temperature, float * p_humidity) {

  uint8_t buf[HS300X_DATA_LEN_BYTE];
  fsp_err_t ret = FSP_SUCCESS;

  wire_init_communication(HS300X_IC2_ADDR);

  /* Make a dummy write request in order to trigger a measurement request */
  /* Actually no data in required but the lower level I2C driver requires at least 1 byte */
  buf[0] = HS300X_MEAS_REQUEST;

  ret = wire_write(buf, 1, false);

  vTaskDelay(HS300X_MEASURE_TIME_TICKS + HS300X_WAKEUP_TIME_TICKS);

  /* Read results */
  ret = wire_read(buf, HS300X_DATA_LEN_BYTE, false);
  if (ret == FSP_SUCCESS) {
    * p_humidity = (float)((((float)(((buf[0] & 0x3f) * 0x100) + buf[1])) / 16383.0) * 100.0);
    * p_temperature = (float)((((float)((unsigned short)((buf[2]) * 0x100 + buf[3]) >> 2)) / 16383.0) * 165.0 - 40.0);
  }

  return ret;
}



void main_thread_entry(void * pvParameters) {
  FSP_PARAMETER_NOT_USED(pvParameters);

  setupUSB( & USBSerial);

  while (1) {

    // fsp_err_t ret = g_i2c_master0.p_api->slaveAddressSet( g_i2c_master0.p_ctrl, 0x44, I2C_MASTER_ADDR_MODE_7BIT );
    fsp_err_t ret = hs300x_temp( & temp, & humidity);
    _printf( & USBSerial, (char * )
      "%.2f,%.2f \n",   temp, humidity);

    // _printf(&USBSerial, (char *)"i2c malfunction");
    vTaskDelay(INTERVAL_MS);
  }

}
