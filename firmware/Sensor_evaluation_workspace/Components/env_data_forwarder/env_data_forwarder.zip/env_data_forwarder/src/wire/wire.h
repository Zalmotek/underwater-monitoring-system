#include <FreeRTOS.h>

#include <r_i2c_master_api.h>
#include <hal_data.h>
#include <event_groups.h>
#include <fsp_common_api.h>
#pragma once


#define I2C_TIMEOUT_TICKS                           (1000)  /*Timeout for the I"C transmission and Reception*/
#define I2C_BUFF_TX_SIZE                            (0x10)  /*I2C Transmission Buffer Size*/
#define I2C_BUFF_RX_SIZE                            (0x50)  /*I2C Reception Buffer Size*/

extern const i2c_master_instance_t g_i2c_master0;


static bool wire_clear_buffer_n(uint8_t* buff_p, size_t n);

static EventGroupHandle_t i2c_sci0_event_handle = {0};
static EventGroupHandle_t i2c_riic0_event_handle = {0};
static StaticEventGroup_t i2c_sci9_event_buf = {0};
static StaticEventGroup_t i2c_riic1_event_buf = {0};
static uint8_t i2c_buff_tx[I2C_BUFF_TX_SIZE] = {0};
static uint8_t i2c_buff_rx[I2C_BUFF_RX_SIZE] = {0};
static uint32_t i2c_count_tx = 0;       /*Used for debug*/
static uint32_t i2c_count_rx = 0;       /*Used for debug*/
static uint16_t i2c_cnt_rx_complete = 0;/*Used for debug*/
static uint16_t i2c_cnt_tx_complete = 0;/*Used for debug*/
static uint16_t i2c_cnt_com_error = 0;  /*Used for debug*/

/***************************************************************************//**
 * @brief     Transmit the data on the I2C Bus
 *
 * @param[in] buf      Address of the buffer that contains the data that have to be transmitted
 * @param[in] len      Buffer length
 * @param[in] restart  If true a restart condition is transmitted (required to read a register)
 *
 * @return    @ref fsp_err_t
*******************************************************************************/

fsp_err_t wire_write( uint8_t* buf, uint32_t buf_len, bool restart );

/***************************************************************************//**
 * @brief     Receive data from the I2C Bus
 *
 * @param[in] buf      Reception Buffer Address
 * @param[in] len      Buffer length
 * @param[in] restart  If true a restart condition is transmitted
 *
 * @return    @ref fsp_err_t
*******************************************************************************/

fsp_err_t wire_read( uint8_t* buf, uint32_t buf_len, bool restart );

/***************************************************************************//**
 * @brief     Read a Register Value (8-bit address) from the I2C Bus
 *
 * @param[in] reg_addr Register Address
 * @param[in] buf      Reception Buffer Address
 * @param[in] len      Buffer length
 *
 * @return    @ref fsp_err_t
*******************************************************************************/

fsp_err_t wire_read_register(uint8_t reg_addr, uint8_t* buf, uint32_t buf_len);

/***************************************************************************//**
 * @brief     Initialize the I2C communication
*******************************************************************************/

fsp_err_t wire_init_communication(uint8_t address);

/**********************************************************************************************************************
 * Private global variables
 *********************************************************************************************************************/

static bool wire_clear_buffer_n(uint8_t* buff_p, size_t n);

void wire_master_callback(i2c_master_callback_args_t *p_args);


