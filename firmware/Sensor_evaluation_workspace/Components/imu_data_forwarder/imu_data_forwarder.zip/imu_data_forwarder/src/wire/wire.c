#include <wire/wire.h>
#include <event_groups.h>


EventGroupHandle_t i2c_event_handle;

fsp_err_t wire_init_communication(uint8_t address)
{
    fsp_err_t ret = FSP_SUCCESS;

    /*Try to Open the connection...*/
    ret = g_i2c_master0.p_api->open(g_i2c_master0.p_ctrl, g_i2c_master0.p_cfg);

    if(ret == FSP_SUCCESS)
    {
        ret = g_i2c_master0.p_api->slaveAddressSet( g_i2c_master0.p_ctrl, address, I2C_MASTER_ADDR_MODE_7BIT );
    }

    /*Clear transmission and reception buffer*/
    wire_clear_buffer_n(i2c_buff_tx, I2C_BUFF_TX_SIZE);
    wire_clear_buffer_n(i2c_buff_rx, I2C_BUFF_RX_SIZE);

    i2c_riic0_event_handle = xEventGroupCreateStatic( &i2c_riic1_event_buf );
    return ret;
}

fsp_err_t wire_read_register(uint8_t reg_addr, uint8_t* buf, uint32_t buf_len)
{

    fsp_err_t ret = FSP_SUCCESS;

    ret = wire_write(&reg_addr, 1, true);

    if(ret == FSP_SUCCESS)
    {
        ret = wire_read(buf, buf_len, false);
    }

    return ret;
}

fsp_err_t wire_write( uint8_t* buf, uint32_t buf_len, bool restart )
{
    fsp_err_t ret = FSP_SUCCESS;;
    EventBits_t events = {0};

    i2c_count_tx++;

    ret = g_i2c_master0.p_api->write( g_i2c_master0.p_ctrl, buf, buf_len, restart);
    FSP_ERROR_RETURN( (ret == FSP_SUCCESS), ret );

    /* Wait for TX end */
    events = xEventGroupWaitBits( i2c_riic0_event_handle,
                                  (1 << I2C_MASTER_EVENT_TX_COMPLETE),
                                  pdTRUE,
                                  pdFALSE,
                                  I2C_TIMEOUT_TICKS );

    FSP_ERROR_RETURN( ((events & (1 << I2C_MASTER_EVENT_TX_COMPLETE)) != 0), FSP_ERR_ABORTED );

    return ret;
}

fsp_err_t wire_read( uint8_t* buf, uint32_t buf_len, bool restart )
{
    fsp_err_t ret = FSP_SUCCESS;
    EventBits_t events = {0};

    i2c_count_rx++;

    ret = g_i2c_master0.p_api->read( g_i2c_master0.p_ctrl, buf, buf_len, restart);

    FSP_ERROR_RETURN( (ret == FSP_SUCCESS), ret );
    /* Wait for RX end */
    events = xEventGroupWaitBits( i2c_riic0_event_handle,
                                  (1 << I2C_MASTER_EVENT_RX_COMPLETE),
                                  pdTRUE,
                                  pdFALSE,
                                  I2C_TIMEOUT_TICKS );
    FSP_ERROR_RETURN( ((events & (1 << I2C_MASTER_EVENT_RX_COMPLETE)) != 0), FSP_ERR_ABORTED );

    ret = FSP_SUCCESS;

    return ret;
}

void wire_master_callback(i2c_master_callback_args_t *p_args)
{
    BaseType_t pxHigherPriorityTaskWoken;

    xEventGroupSetBitsFromISR( i2c_riic0_event_handle,
                               (1 << p_args->event),
                               &pxHigherPriorityTaskWoken );


    switch(p_args->event)
    {
        case I2C_MASTER_EVENT_RX_COMPLETE:
            i2c_cnt_rx_complete++;
            break;
        case I2C_MASTER_EVENT_TX_COMPLETE:
            i2c_cnt_tx_complete++;
            break;
        case I2C_MASTER_EVENT_ABORTED:
            i2c_cnt_com_error++;
            break;
        default:
            break;
    }
}

static bool wire_clear_buffer_n(uint8_t* buff_p, size_t n)
{
    bool ret = false;

    ret = (buff_p != NULL);
    if(ret)
    {
        for(size_t i = 0; i < n; i++)
        {
            buff_p[i] = 0x00;
        }
    }

    return ret;
}



