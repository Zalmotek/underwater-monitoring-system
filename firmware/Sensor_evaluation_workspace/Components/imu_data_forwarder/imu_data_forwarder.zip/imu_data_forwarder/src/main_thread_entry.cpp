#include <main_thread.h>
#include <math.h>
#include <serial/serial.h>
#include <imu_settings.h>

#define INTERVAL_MS 20

static float accX, accY, accZ, gyroX, gyroY, gyroZ, pitch, yaw, roll;


SerialPort USBSerial;

static void setupIMU(){
    wire_init_communication(0x28);
    bno055.p_api -> open(bno055.p_ctrl, bno055.p_cfg);

}

static fsp_err_t readIMU() {
  fsp_err_t ret;
  wire_init_communication(0x28);
  ret = bno055.p_api -> readAccelerometer(bno055.p_ctrl, &accX, &accY, &accZ);

  if (ret == FSP_SUCCESS) {
    wire_init_communication(0x28);
    ret = bno055.p_api -> readGyroscope(bno055.p_ctrl, &gyroX, &gyroY, &gyroZ);

    if (ret == FSP_SUCCESS) {
      wire_init_communication(0x28);
      ret = bno055.p_api -> readEulerAngles(bno055.p_ctrl, &pitch, &roll, &yaw);

      if (ret == FSP_SUCCESS) {
        _printf( & USBSerial, (char * )
          "%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f \n",
          accX, accY, accZ, gyroX, gyroY, gyroZ, pitch, roll, yaw
        );
        return ret;
      }
    }
  }

  return ret;
}



void main_thread_entry(void * pvParameters) {
    FSP_PARAMETER_NOT_USED(pvParameters);

    setupIMU();
    setupUSB(&USBSerial);

    while (1){
        readIMU();
        vTaskDelay (INTERVAL_MS);
    }
}
