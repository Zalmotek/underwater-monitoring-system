/*
 * imu_settings.h
 *
 *  Created on: Feb 3, 2023
 *      Author: crist
 */

#ifndef IMU_SETTINGS_H_
#define IMU_SETTINGS_H_

#include <components/bno055/sf_bno055.h>
extern "C" {
    #include <wire/wire.h>
}

static sf_bno055_ctrl_t bno055_ctrl = {
    0
};

static const sf_bno055_cfg_t bno055_cfg = {
    .device = & g_i2c_master0,
    .reset_pin = IOPORT_PORT_00_PIN_05, //
    .ioport = & g_ioport,
    .acc_cfg = {
        BNO055_ACC_RANGE_4G,
        BNO055_ACC_BANDWIDTH_250_HZ,
        BNO055_ACC_UNIT_M_S2
    },
    .gyro_cfg = {
        BNO055_GYRO_RANGE_500dps,
        BNO055_GYRO_BANDWIDTH_230_HZ,
        BNO055_GYRO_UNIT_DPS
    },
    .mag_cfg = {
        BNO055_MAG_OUT_RATE_30_HZ,
        BNO055_MAG_OP_MODE_REGULAR
    },
    .temp_cfg = {
        BNO055_TEMP_SOURCE_ACC,
        BNO055_TEMP_UNIT_C
    }
};

static sf_bno055_instance_t bno055 = {
    .p_ctrl = & bno055_ctrl,
    .p_cfg = & bno055_cfg,
    .p_api = & g_sf_bno055_api
};




#endif /* IMU_SETTINGS_H_ */
