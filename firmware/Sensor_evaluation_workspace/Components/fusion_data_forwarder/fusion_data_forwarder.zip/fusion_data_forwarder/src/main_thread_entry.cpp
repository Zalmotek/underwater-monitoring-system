#include <main_thread.h>
#include <math.h>
#include <serial/serial.h>
#include <imu_settings.h>
#include <adc_settings.h>
#include <temp_settings.h>

#define INTERVAL_MS                20

static float accX, accY, accZ, gyroX, gyroY, gyroZ, pitch, yaw, roll, temp, humidity;

SerialPort USBSerial;

static fsp_err_t readTemp(float * p_temperature, float * p_humidity) {

  uint8_t buf[HS300X_DATA_LEN_BYTE];
  fsp_err_t ret = FSP_SUCCESS;

  wire_init_communication(HS300X_IC2_ADDR);

  /* Make a dummy write request in order to trigger a measurement request */
  /* Actually no data in required but the lower level I2C driver requires at least 1 byte */
  buf[0] = HS300X_MEAS_REQUEST;

  ret = wire_write(buf, 1, false);

  vTaskDelay(HS300X_MEASURE_TIME_TICKS + HS300X_WAKEUP_TIME_TICKS);

  /* Read results */
  ret = wire_read(buf, HS300X_DATA_LEN_BYTE, false);
  if (ret == FSP_SUCCESS) {
    * p_humidity = (float)((((float)(((buf[0] & 0x3f) * 0x100) + buf[1])) / 16383.0) * 100.0);
    * p_temperature = (float)((((float)((unsigned short)((buf[2]) * 0x100 + buf[3]) >> 2)) / 16383.0) * 165.0 - 40.0);
  }

  return ret;
}


static void setupIMU(){
    wire_init_communication(0x28);
    bno055.p_api -> open(bno055.p_ctrl, bno055.p_cfg);

}

static fsp_err_t readIMU() {
  fsp_err_t ret;
  wire_init_communication(0x28);
  ret = bno055.p_api -> readAccelerometer(bno055.p_ctrl, &accX, &accY, &accZ);

  if (ret == FSP_SUCCESS) {
    wire_init_communication(0x28);
    ret = bno055.p_api -> readGyroscope(bno055.p_ctrl, &gyroX, &gyroY, &gyroZ);

    if (ret == FSP_SUCCESS) {
      wire_init_communication(0x28);
      ret = bno055.p_api -> readEulerAngles(bno055.p_ctrl, &pitch, &roll, &yaw);

      if (ret == FSP_SUCCESS) {
        return ret;
      }
    }
  }

  return ret;
}

void adc_callback(adc_callback_args_t *p_args){
    if((NULL != p_args) && (ADC_EVENT_SCAN_COMPLETE == p_args->event)){
        scanEnded = true;
    }
}


// this initiates an ADC scan
// since we are in single scan mode, we need to do this after every consecutive read
static void startScan(){
    fsp_err_t err;

    err = R_ADC_Open(&g_adc0_ctrl, &g_adc0_cfg);
    if( err == FSP_SUCCESS){
        err = R_ADC_ScanCfg(&g_adc0_ctrl, &g_adc0_channel_cfg);
        if( err == FSP_SUCCESS){
            err = R_ADC_ScanStart(&g_adc0_ctrl);
            R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MICROSECONDS);

        }
    }
}

static void sampleADC(){
    R_ADC_Read(&g_adc0_ctrl, ADC_CHANNEL_3, &currentReading);
    scanEnded = false;

    offsetI = offsetI + ((currentReading-offsetI)/4096);
    filteredI = currentReading - offsetI;
    sqI = filteredI * filteredI;
    sumI += sqI;
    ++cycleCounter;

    // initiate a new scan when we are ready to process the next sample
    startScan();
}

static double calculateCurrent(){
    double I_RATIO = ICAL *((AREF/1000.0) / (ADC_COUNTS));
    double Irms = I_RATIO * sqrt(sumI / CYCLES);
    sumI = 0;

    return Irms;
}


static void readADC(){
    if(scanEnded) sampleADC();

    if(cycleCounter > CYCLES){
       rmsCurrent = calculateCurrent();

       cycleCounter = 0;
    }

}

static void print(){
    _printf(&USBSerial, (char * )
             "%.2f,%.2f,%.2f,%.2f,%.2f,%.2f\n",
             accX, accY, accZ,
             rmsCurrent, temp, humidity
             );
}

void main_thread_entry(void * pvParameters) {
    FSP_PARAMETER_NOT_USED(pvParameters);

    setupIMU();
    setupUSB(&USBSerial);
    startScan();

    while (1){
        readIMU();
        readADC();
        readTemp(&temp, &humidity);
        print();


        vTaskDelay (INTERVAL_MS);
    }
}
