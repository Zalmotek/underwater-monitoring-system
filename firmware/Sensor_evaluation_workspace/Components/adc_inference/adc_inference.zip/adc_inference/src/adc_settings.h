/*
 * adc_settings.h
 *
 *  Created on: Feb 3, 2023
 *      Author: crist
 */

#ifndef ADC_SETTINGS_H_
#define ADC_SETTINGS_H_


#define ICAL 20 // calibration value for current calculation
#define INTERVAL_MS 5
#define CYCLES 10
#define ADC_BITS    12
#define ADC_COUNTS  (1<<ADC_BITS)
#define AREF 3300
#include <cstdint>

volatile bool scanEnded = false;

// variables used for calculating the current root means square
static int cycleCounter = 0;
static uint16_t currentReading;
static float filteredI = 0;
static float offsetI = ADC_COUNTS>>1;
static float sqI, sumI = 0.00;

static double rmsCurrent;



#endif /* ADC_SETTINGS_H_ */
